Thanks for downloading my free Instagram Sign In button.

You are free to use the buttons and PSD however you wish, personal and commercial. The only thing I ask is to check out my Instagram mobile site called Instabam.com. It works on most touch screen phones and uses your GPS to find Instagram photos near where you are standing!

Links back to my blog and retweets are MUCH appreciated!

Cheers

Murat 

www.mobileinc.co.uk